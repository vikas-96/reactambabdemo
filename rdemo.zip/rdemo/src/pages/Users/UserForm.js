import React from "react";
import { Form, FormGroup, Input, Label, Row, Col } from "reactstrap";

class UserForm extends React.Component {
  constructor(props) {
    super(props);

    this.handleChange = this.handleChange.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
    this.state = {
      first_name: "",
      last_name: "",
      email: "",
      gender: "",
      hob: []
    };
  }

  handleChange(e) {
    this.setState({ [e.target.name]: e.target.value });
  }

  handleSubmit(e) {
    e.preventDefault();
    // this.props.handleSubmit(data);
    console.log(this.state);
  }

  render() {
    const checkboxes = [
      {
        name: "hob",
        value: "cric",
        label: "Cric"
      },
      {
        name: "hob",
        value: "ftbl",
        label: "Ftbl"
      }
    ];

    return (
      <Form onSubmit={this.handleSubmit}>
        <Row>
          <Col md={4}>
            <FormGroup>
              <Label for="first_name">First Name</Label>
              <Input
                type="text"
                name="first_name"
                id="first_name"
                placeholder="First Name"
                value={this.state.first_name}
                onChange={this.handleChange}
              />
            </FormGroup>
          </Col>
          <Col md={4}>
            <FormGroup>
              <Label for="last_name">Last Name</Label>
              <Input
                type="text"
                name="last_name"
                id="last_name"
                placeholder="Last Name"
                value={this.state.last_name}
                onChange={this.handleChange}
              />
            </FormGroup>
          </Col>
          <Col md={4}>
            <FormGroup>
              <Label for="email">Email</Label>
              <Input
                type="email"
                name="email"
                id="email"
                placeholder="Email-Id "
                value={this.state.email}
                onChange={this.handleChange}
              />
            </FormGroup>
          </Col>
        </Row>
        <Row>
          <Col md={4}>
            <FormGroup>
              <Label for="gender">Gender</Label>
              <br />
              <Input
                type="radio"
                name="gender"
                value="male"
                checked={this.state.gender === "male"}
                onChange={this.handleChange}
              />
              Male
              <Input
                type="radio"
                name="gender"
                value="female"
                checked={this.state.gender === "female"}
                onChange={this.handleChange}
              />
              Female
            </FormGroup>
          </Col>
          <Col md={4}>
            <FormGroup>
              {checkboxes.map(item => (
                <label>
                  {item.label}
                  <Input
                    type="checkbox"
                    name={item.name}
                    value={item.value}
                    // checked={this.state.checkedItems.get(item.name)}
                    onChange={this.handleChange}
                  />
                </label>
              ))}
            </FormGroup>
          </Col>
        </Row>
        <Input type="submit" />
      </Form>
    );
  }
}

export default UserForm;
