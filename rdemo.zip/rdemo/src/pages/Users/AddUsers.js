import React from "react";
import UserForm from "./UserForm";

class AddUsers extends React.Component {
  render() {
    // let data = "asd";
    const onSubmit = () => {
      return <p>asd</p>;
    };

    return <UserForm handleSubmit={this.onSubmit} data={[]} />;
  }
}

export default AddUsers;
